export namespace WebSocket {
    export const State = [
        'CONNECTING',
        'OPEN',
        'CLOSING',
        'CLOSED'
    ]
}